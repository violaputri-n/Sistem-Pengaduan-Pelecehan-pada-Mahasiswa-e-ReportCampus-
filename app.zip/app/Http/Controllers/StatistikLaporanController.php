<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class StatistikLaporanController extends Controller
{
    public function index()
    {
        $total = DB::table('laporan_kasus')->count();

        $pending = DB::table('laporan_kasus')
            ->where('status', 'pending')
            ->count();

        $resolved = DB::table('laporan_kasus')
            ->where('status', 'resolved')
            ->count();

        return response()->json([
            'total'    => $total,
            'pending'  => $pending,
            'resolved' => $resolved,
        ]);
    }
}
