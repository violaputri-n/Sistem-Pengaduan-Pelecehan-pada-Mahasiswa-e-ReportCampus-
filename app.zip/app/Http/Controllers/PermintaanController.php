<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PermintaanKonseling;
use App\Models\User;

class PermintaanController extends Controller
{
    public function index()
    {
        return PermintaanKonseling::with('mahasiswa')->get();
    }

    public function update(Request $request, $id)
    {
        $data = PermintaanKonseling::findOrFail($id);
        $data->update(['status' => $request->status]);

        return response()->json(['message' => 'Status updated']);
    }
}
