<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Notification;

class NotificationController extends Controller
{
    /**
     * Ambil semua notifikasi milik user yang login
     */
    public function index()
    {
        return response()->json(
            Notification::where('user_id', auth()->id())
                ->orderByDesc('created_at')
                ->get()
        );
    }

    /**
     * Tandai notifikasi sebagai dibaca
     */
    public function read($id)
    {
        $notif = Notification::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        $notif->update([
            'is_read' => true
        ]);

        return response()->json([
            'message' => 'Notifikasi dibaca'
        ]);
    }
}
