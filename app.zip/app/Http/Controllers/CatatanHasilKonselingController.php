<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CatatanHasilKonseling;

class CatatanHasilKonselingController extends Controller
{
    public function index()
    {
        $catatan = CatatanHasilKonseling::orderBy('tanggal', 'desc')->get();
        return view('catatan_hasil_konseling.index', compact('catatan'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_mahasiswa' => 'required|string|max:255',
            'catatan' => 'required|string',
            'konselor' => 'required|string|max:255',
            'tanggal' => 'required|date',
        ]);

        CatatanHasilKonseling::create($request->all());

        return redirect()->route('catatan.index')->with('success', 'Catatan berhasil ditambahkan');
    }
}
