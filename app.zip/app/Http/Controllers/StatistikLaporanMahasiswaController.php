<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StatistikLaporanMahasiswaController extends Controller
{
    public function index(Request $request)
    {
        $mahasiswaId = $request->user()->id;

        // Total laporan
        $totalLaporan = DB::table('laporan_kasus')
            ->where('mahasiswa_id', $mahasiswaId)
            ->count();

        // Laporan pending
        $laporanPending = DB::table('laporan_kasus')
            ->where('mahasiswa_id', $mahasiswaId)
            ->where('status', 'pending')
            ->count();

        // Konsultasi menunggu
        $konsultasiMenunggu = DB::table('konsultasi')
            ->where('mahasiswa_id', $mahasiswaId)
            ->where('status', 'menunggu')
            ->count();

        // Notifikasi belum dibaca
        $notifikasiBelumBaca = DB::table('notifications')
            ->where('user_id', $mahasiswaId)
            ->where('is_read', false)
            ->count();

        return response()->json([
            'total_laporan' => $totalLaporan,
            'laporan_pending' => $laporanPending,
            'konsultasi_menunggu' => $konsultasiMenunggu,
            'notifikasi_belum_baca' => $notifikasiBelumBaca,
        ]);
    }
}
