<?php

namespace App\Http\Controllers;

use App\Models\Konsultasi;
use Illuminate\Http\Request;
use App\Models\Notification;
use Carbon\Carbon;


class KonsultasiController extends Controller
{
    public function tanggapanSchedule(Request $request, $id)
{
    $request->validate([
        'message' => 'required|string',
        'tanggal' => 'required|date',
    ]);

    $konsultasi = Konsultasi::findOrFail($id);

    $konsultasi->update([
        'status' => 'ongoing',
        'jadwal_konsultasi' => Carbon::parse($request->tanggal),
        'tanggapan_konselor' => $request->message,
    ]);

    Notification::create([
        'user_id' => $konsultasi->mahasiswa_id,
        'title' => 'Jadwal Konsultasi Diterima',
        'message' => 'Konselor telah membalas dan menjadwalkan konsultasi Anda pada '
            . Carbon::parse($request->tanggal)->format('d M Y H:i'),
    ]);

    return response()->json([
        'message' => 'Tanggapan dan notifikasi berhasil dikirim'
    ]);
}
    
    public function index()
    {
        $data = Konsultasi::with('mahasiswa:id,name')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($data);
    }

    // ============================
    // UPDATE STATUS
    // ============================
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:pending,approved,ongoing,completed,rejected',
        ]);

        $konsultasi = Konsultasi::find($id);

        if (!$konsultasi) {
            return response()->json([
                'message' => 'Data konsultasi tidak ditemukan'
            ], 404);
        }

        $konsultasi->status = $request->status;
        $konsultasi->save();

        return response()->json([
            'message' => 'Status berhasil diperbarui',
            'data' => $konsultasi
        ]);
    }
}
