<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\LaporanKasus;

class LaporanKasusController extends Controller
{

    public function index()
    {
        $laporan = DB::table('laporan_kasus')
            ->leftJoin('users', 'laporan_kasus.mahasiswa_id', '=', 'users.id')
            ->select(
                'laporan_kasus.id',
                DB::raw("COALESCE(users.name, '-') as mahasiswa_nama"),
                'laporan_kasus.kategori_kasus',
                'laporan_kasus.deskripsi',
                'laporan_kasus.waktu_kejadian',
                'laporan_kasus.lokasi',
                'laporan_kasus.status'
            )
            ->orderByDesc('laporan_kasus.id')
            ->get();

        return response()->json([
            'status'  => true,
            'message' => 'Daftar laporan masuk',
            'data'    => $laporan
        ]);
    }

    public function tindaklanjut($id)
    {
        $laporan = DB::table('laporan_kasus')->where('id', $id)->first();

        if (!$laporan) {
            return response()->json([
                'status'  => false,
                'message' => 'Laporan tidak ditemukan'
            ], 404);
        }

        DB::table('laporan_kasus')
            ->where('id', $id)
            ->update([
                'status'     => 'under_review',
                'updated_at' => now()
            ]);

        return response()->json([
            'status'  => true,
            'message' => 'Laporan berhasil ditindaklanjuti'
        ]);
    }

    public function tanggapan(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'tanggapan' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $updated = DB::table('laporan_kasus')
            ->where('id', $id)
            ->update([
                'tanggapan'  => $request->tanggapan,
                'status'     => 'resolved',
                'updated_at' => now()
            ]);

        if (!$updated) {
            return response()->json([
                'status'  => false,
                'message' => 'Laporan tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status'  => true,
            'message' => 'Tanggapan berhasil dikirim'
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kategori_kasus' => 'required|string',
            'deskripsi'      => 'required|min:20',
            'waktu_kejadian' => 'required|date',
            'lokasi'         => 'required|string',
            'bukti_file'     => 'nullable|file|max:5120'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        if (!auth()->check()) {
            return response()->json([
                'status' => false,
                'message' => 'Unauthorized'
            ], 401);
        }

        $buktiPath = null;
        if ($request->hasFile('bukti_file')) {
            $buktiPath = $request->file('bukti_file')
                ->store('bukti_laporan', 'public');
        }

        $laporan = LaporanKasus::create([
            'mahasiswa_id'   => auth()->id(), // ⬅️ NO FALLBACK
            'kategori_kasus' => $request->kategori_kasus,
            'deskripsi'      => $request->deskripsi,
            'waktu_kejadian' => $request->waktu_kejadian,
            'lokasi'         => $request->lokasi,
            'bukti_file'     => $buktiPath,
            'status'         => 'pending',
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'Laporan berhasil dikirim',
            'id'      => $laporan->id
        ], 201);
    }

public function laporanTerbaru(Request $request)
    {
        $limit = $request->get('limit', 3);
        $mahasiswaId = auth()->id();

        $laporan = LaporanKasus::where('mahasiswa_id', $mahasiswaId)
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'kategori_kasus' => $item->kategori_kasus,
                    'deskripsi' => \Str::limit($item->deskripsi, 80),
                    'status' => $item->status,
                    'lokasi' => $item->lokasi,
                    'waktu_kejadian' => $item->waktu_kejadian,
                ];
            });

        return response()->json([
            'status' => true,
            'data' => $laporan,
        ]);
    }

    // Riwayat laporan mahasiswa
    public function riwayatMahasiswa()
    {
        $mahasiswaId = auth()->id();

        $laporan = LaporanKasus::where('mahasiswa_id', $mahasiswaId)
            ->orderByDesc('created_at')
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'kategori_kasus' => $item->kategori_kasus,
                    'deskripsi' => $item->deskripsi,
                    'status' => $item->status,
                    'lokasi' => $item->lokasi,
                    'waktu_kejadian' => $item->waktu_kejadian,
                    'tanggapan' => $item->tanggapan,
                    'bukti_file' => $item->bukti_file ? asset('storage/' . $item->bukti_file) : null,
                    'dibuat_pada' => $item->created_at->format('d M Y H:i'),
                ];
            });

        return response()->json([
            'status' => true,
            'data' => $laporan,
        ]);
    }

    public function getKategoriKasus()
    {
        $kategori = DB::table('kategori_kasus')
            ->select('id', 'nama_kategori', 'deskripsi')
            ->orderBy('nama_kategori', 'asc')
            ->get();

        return response()->json([
            'status' => true,
            'data'   => $kategori
        ]);
    }





}
