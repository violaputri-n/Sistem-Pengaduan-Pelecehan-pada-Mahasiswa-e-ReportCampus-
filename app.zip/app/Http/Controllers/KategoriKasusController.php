<?php

namespace App\Http\Controllers;

use App\Models\KategoriKasus;
use Illuminate\Http\Request;

class KategoriKasusController extends Controller
{
    public function index()
    {
        return KategoriKasus::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_kategori' => 'required|unique:kategori_kasus',
            'deskripsi'     => 'nullable'
        ]);

        return KategoriKasus::create($request->all());
    }

    public function update(Request $request, KategoriKasus $kategoriKasus)
    {
        $request->validate([
            'nama_kategori' => 'required|unique:kategori_kasus,nama_kategori,' . $kategoriKasus->id,
        ]);

        $kategoriKasus->update($request->all());

        return $kategoriKasus;
    }

    public function destroy(KategoriKasus $kategoriKasus)
    {
        $kategoriKasus->delete();

        return response()->json(['message' => 'Kategori deleted']);
    }
}
