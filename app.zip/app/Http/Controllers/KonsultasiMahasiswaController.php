<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KonsultasiMahasiswaController extends Controller
{
    public function index(Request $request)
    {
        $limit = $request->get('limit', 3);
        $mahasiswaId = $request->user()->id;

        $konsultasi = DB::table('konsultasi')
            ->where('mahasiswa_id', $mahasiswaId)
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                // disesuaikan agar field kompatibel dengan ActivityColumn React
                return [
                    'id' => $item->id,
                    'kategori_kasus' => $item->topik, // React expects 'kategori_kasus'
                    'deskripsi' => '-', // kosong jika tidak ada deskripsi
                    'status' => $item->status,
                    'lokasi' => '-', // kosong
                    'waktu_kejadian' => $item->waktu, // React expects 'waktu_kejadian'
                ];
            });

        return response()->json([
            'status' => true,
            'data' => $konsultasi,
        ]);
    }
}
