<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CatatanHasilKonseling;

class CatatanApiController extends Controller
{
    public function index()
    {
        $catatan = CatatanHasilKonseling::orderBy('tanggal', 'desc')->get();
        return response()->json($catatan);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_mahasiswa' => 'required|string|max:255',
            'catatan' => 'required|string',
            'konselor' => 'required|string|max:255',
            'tanggal' => 'required|date',
        ]);

        $catatan = CatatanHasilKonseling::create($request->all());

        return response()->json($catatan, 201);
    }
}
