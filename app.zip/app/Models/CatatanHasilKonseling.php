<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatatanHasilKonseling extends Model
{
    use HasFactory;

    protected $table = 'catatan_hasil_konseling';

    protected $fillable = [
        'nama_mahasiswa',
        'catatan',
        'konselor',
        'tanggal',
    ];
}
