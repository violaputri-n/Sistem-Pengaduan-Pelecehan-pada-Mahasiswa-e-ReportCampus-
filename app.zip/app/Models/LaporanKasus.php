<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User; 
class LaporanKasus extends Model
{
    use HasFactory;

    protected $table = 'laporan_kasus';

    protected $fillable = [
        'mahasiswa_id',
        'kategori_kasus',
        'deskripsi',
        'waktu_kejadian',
        'lokasi',
        'bukti_file',
        'status',
        'tanggapan',
    ];

protected $casts = [
    'waktu_kejadian' => 'datetime',
    'created_at'     => 'datetime',
];

    public function mahasiswa()
    {
        return $this->belongsTo(User::class, 'mahasiswa_id');
    }
}
