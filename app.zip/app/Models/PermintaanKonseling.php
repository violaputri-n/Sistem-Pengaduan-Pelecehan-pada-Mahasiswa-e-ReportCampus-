<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PermintaanKonseling extends Model
{
    use HasFactory;

    protected $table = 'permintaan_konseling';

    protected $fillable = [
        'user_id',
        'topik',
        'metode',
        'status',
    ];

    // relasi ke user (mahasiswa)
    public function mahasiswa()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
