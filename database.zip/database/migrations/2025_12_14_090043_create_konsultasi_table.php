<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('konsultasi', function (Blueprint $table) {
            $table->id();

            $table->foreignId('mahasiswa_id')
                  ->constrained('users')
                  ->onDelete('cascade');

            $table->string('topik');
            $table->text('deskripsi');

            $table->enum('status', [
                'pending',
                'approved',
                'ongoing',
                'completed',
                'rejected'
            ])->default('pending');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('konsultasi');
    }
};