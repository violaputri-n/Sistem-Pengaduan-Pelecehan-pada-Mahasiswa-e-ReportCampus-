<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Admin Utama',
            'email' => 'admin@mail.com',
            'password' => Hash::make('password'),
            'role' => 'admin'
        ]);

        User::create([
            'name' => 'Petugas Sistem',
            'email' => 'petugas@mail.com',
            'password' => Hash::make('password'),
            'role' => 'petugas'
        ]);

        User::create([
            'name' => 'Konselor Bimbingan',
            'email' => 'konselor@mail.com',
            'password' => Hash::make('password'),
            'role' => 'konselor'
        ]);

        User::create([
            'name' => 'Mahasiswa Baru',
            'email' => 'mahasiswa@mail.com',
            'password' => Hash::make('password'),
            'role' => 'mahasiswa'
        ]);
    }
}
