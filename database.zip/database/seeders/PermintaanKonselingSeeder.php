<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PermintaanKonselingSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('permintaan_konseling')->insert([
            'user_id'     => 4, // ID user role mahasiswa
            'topik'       => 'Stres Akademik',
            'metode'      => 'chat',
            'status'      => 'pending',
            'created_at'  => now(),
            'updated_at'  => now(),
        ]);
    }
}
