import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";

import RegisterMahasiswa from "./pages/RegisterMahasiswa";

import DashboardAdmin from "./pages/admin/DashboardAdmin";
import DashboardPetugas from "./pages/petugas/DashboardPetugas";
import DashboardKonselor from "./pages/konselor/DashboardKonselor";
import DashboardMahasiswa from "./pages/mahasiswa/DashboardMahasiswa";

import UserManagement from "./pages/admin/UserManagement";
import CategoryManagement from "./pages/admin/CategoryManagement";

import KonselorPermintaan from "./pages/konselor/PermintaanList";
import KonselorChat from "./pages/konselor/KonselorChat"; 
import CatatanHasilKonseling from "./pages/konselor/CatatanHasilKonseling";

import DaftarLaporanMasuk from "./pages/petugas/DaftarLaporanMasuk";
import KirimTanggapan from "./pages/petugas/KirimTanggapan";

import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
    return (
        <BrowserRouter>
            <Routes>

                <Route path="/" element={<Navigate to="/login" replace />} />

                <Route path="/login" element={<Login />} />

                <Route path="/register-mahasiswa" element={<RegisterMahasiswa />} />

                {/* ===================== ADMIN ===================== */}
                <Route
                    path="/admin/dashboard"
                    element={
                        <ProtectedRoute role="admin">
                            <DashboardAdmin />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/admin/users"
                    element={
                        <ProtectedRoute role="admin">
                            <UserManagement />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/admin/kategori"
                    element={
                        <ProtectedRoute role="admin">
                            <CategoryManagement />
                        </ProtectedRoute>
                    }
                />

                {/* ===================== PETUGAS ===================== */}
                <Route
                    path="/petugas/dashboard"
                    element={
                        <ProtectedRoute role="petugas">
                            <DashboardPetugas />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/petugas/daftar-laporan"
                    element={
                        <ProtectedRoute role="petugas">
                            <DaftarLaporanMasuk />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/petugas/tanggapan/:laporanId"
                    element={
                        <ProtectedRoute role="petugas">
                            <KirimTanggapan />
                        </ProtectedRoute>
                    }
                />

                {/* ===================== KONSELOR ===================== */}
                <Route
                    path="/konselor/dashboard"
                    element={
                        <ProtectedRoute role="konselor">
                            <DashboardKonselor />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/konselor/permintaan"
                    element={
                        <ProtectedRoute role="konselor">
                            <KonselorPermintaan />
                        </ProtectedRoute>
                    }
                />

                {/* 🔥 CHAT KONSELOR */}
                <Route
                    path="/konselor/chat/:id"
                    element={
                        <ProtectedRoute role="konselor">
                            <KonselorChat />
                        </ProtectedRoute>
                    }
                />

                <Route
                    path="/konselor/catatan/:id"
                    element={
                        <ProtectedRoute role="konselor">
                            <CatatanHasilKonseling />
                        </ProtectedRoute>
                    }
                />

                {/* ===================== MAHASISWA ===================== */}
                <Route
                    path="/mahasiswa/dashboard"
                    element={
                        <ProtectedRoute role="mahasiswa">
                            <DashboardMahasiswa />
                        </ProtectedRoute>
                    }
                />

                 <Route
                    path="/mahasiswa/laporan"
                    element={
                        <ProtectedRoute role="mahasiswa">
                            <DashboardMahasiswa />
                        </ProtectedRoute>
                    }
                />

                 <Route
                    path="/mahasiswa/konsultasi"
                    element={
                        <ProtectedRoute role="mahasiswa">
                            <DashboardMahasiswa />
                        </ProtectedRoute>
                    }
                />

                 <Route
                    path="/mahasiswa/riwayat"
                    element={
                        <ProtectedRoute role="mahasiswa">
                            <DashboardMahasiswa />
                        </ProtectedRoute>
                    }
                />

                 <Route
                    path="/mahasiswa/notifikasi"
                    element={
                        <ProtectedRoute role="mahasiswa">
                            <DashboardMahasiswa />
                        </ProtectedRoute>
                    }
                />

                {/* 404 */}
                <Route path="*" element={<h1>404 Not Found</h1>} />

            </Routes>
        </BrowserRouter>
    );
}
