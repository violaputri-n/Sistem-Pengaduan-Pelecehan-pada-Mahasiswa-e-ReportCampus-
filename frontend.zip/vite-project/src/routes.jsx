import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";

// dashboard langsung di folder pages
import AdminDashboard from "./pages/AdminDashboard";
import KonselorDashboard from "./pages/KonselorDashboard";
import MahasiswaDashboard from "./pages/MahasiswaDashboard";

// Mahasiswa pages
import BuatLaporanKasus from "./pages/mahasiswa/BuatLaporanKasus";
import StatusLaporan from "./pages/mahasiswa/StatusLaporan";
import RiwayatLaporan from "./pages/mahasiswa/RiwayatLaporan";
import KonsultasiOnline from "./pages/mahasiswa/KonsultasiOnline";
import ChatKonselor from "./pages/mahasiswa/ChatKonselor";
import Notifikasi from "./pages/mahasiswa/NotifikasiMahasiswa";

// Petugas pages
import DashboardPetugas from "./pages/petugas/DashboardPetugas";
import PageDaftarLaporanMasuk from "./pages/petugas/PageDaftarLaporanMasuk";
import PageTindakLanjutLaporan from "./pages/petugas/PageTindakLanjutLaporan";
import PageKirimTanggapan from "./pages/petugas/PageKirimTanggapan";

export default function AppRoutes() {
    return (
        <Routes>

            {/* Login */}
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Login />} />

            {/* Admin Dashboard */}
            <Route path="/admin/dashboard" element={<AdminDashboard />} />

            {/* Petugas Dashboard */}
            <Route path="/petugas/dashboard" element={<DashboardPetugas />} />
            <Route path="/petugas/daftar-laporan" element={<PageDaftarLaporanMasuk />} />
            <Route path="/petugas/tindaklanjut/:laporanId" element={<PageTindakLanjutLaporan />} />
            <Route path="/petugas/tanggapan/:laporanId" element={<PageKirimTanggapan />} />

            {/* Konselor Dashboard */}
            <Route path="/konselor/dashboard" element={<KonselorDashboard />} />

            {/* Mahasiswa Dashboard */}
            <Route path="/mahasiswa/dashboard" element={<MahasiswaDashboard />} />

            {/* Mahasiswa - Laporan Kasus */}
            <Route path="/mahasiswa/buat-laporan" element={<BuatLaporanKasus />} />
            <Route path="/mahasiswa/status-laporan" element={<StatusLaporan />} />
            <Route path="/mahasiswa/riwayat-laporan" element={<RiwayatLaporan />} />

            {/* Mahasiswa - Konsultasi */}
            <Route path="/mahasiswa/konsultasi" element={<KonsultasiOnline />} />
            <Route path="/mahasiswa/chat/:konsultasiId" element={<ChatKonselor />} />

            {/* Mahasiswa - Notifikasi */}
            <Route path="/mahasiswa/notifikasi" element={<Notifikasi />} />

        </Routes>
    );
}
