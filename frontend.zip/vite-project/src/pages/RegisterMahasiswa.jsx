import { useState } from "react";
import api from "../api/axios";
import { useNavigate } from "react-router-dom";

export default function RegisterMahasiswa() {
    const navigate = useNavigate();

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleRegister = async (e) => {
        e.preventDefault();
        setError("");

        if (!name || !email || !password) {
            setError("Semua field wajib diisi");
            return;
        }

        setLoading(true);

        try {
            const response = await api.post("/register/mahasiswa", {
                name,
                email,
                password,
            });

            // simpan token & role
            localStorage.setItem("token", response.data.token);
            localStorage.setItem("role", "mahasiswa");

            alert("Registrasi berhasil!");
            navigate("/mahasiswa/dashboard");
        } catch (err) {
            console.error(err.response || err);
            setError("Registrasi gagal, email mungkin sudah digunakan");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={wrapper}>
            <form onSubmit={handleRegister} style={form}>
                <h2>Register Mahasiswa</h2>

                {error && <p style={{ color: "red" }}>{error}</p>}

                <input
                    type="text"
                    placeholder="Nama Lengkap"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />

                <button type="submit" disabled={loading}>
                    {loading ? "Mendaftar..." : "Register"}
                </button>

                <button
                    type="button"
                    onClick={() => navigate("/login")}
                    style={btnSecondary}
                >
                    Kembali ke Login
                </button>
            </form>
        </div>
    );
}

const wrapper = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "#f0f2f5",
};

const form = {
    background: "white",
    padding: "40px",
    borderRadius: "10px",
    width: "320px",
    display: "flex",
    flexDirection: "column",
    gap: "15px",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
};

const btnSecondary = {
    background: "#6c757d",
    color: "white",
    border: "none",
    padding: "10px",
    borderRadius: "5px",
};
