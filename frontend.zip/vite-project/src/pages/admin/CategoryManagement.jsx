import { useEffect, useState } from "react";
import api from "../../api/axios";
import DashboardLayout from "../../components/DashboardLayout";

export default function CategoryManagement() {
    const [kategori, setKategori] = useState([]);
    const [form, setForm] = useState({
        nama_kategori: "",
        deskripsi: "",
    });

    function loadData() {
        api.get("/kategori")
            .then(res => setKategori(res.data))
            .catch(err => console.log(err));
    }

    useEffect(() => {
        loadData();
    }, []);

    function handleSubmit(e) {
        e.preventDefault();
        api.post("/kategori", form)
            .then(() => {
                setForm({ nama_kategori: "", deskripsi: "" });
                loadData();
            })
            .catch(err => console.log(err));
    }

    function handleDelete(id) {
        api.delete(`/kategori/${id}`)
            .then(() => loadData())
            .catch(err => console.log(err));
    }

    return (
        <DashboardLayout role="Admin">
            <h1 style={{ marginBottom: "20px" }}>Manajemen Kategori Kasus</h1>

            {/* FORM TAMBAH KATEGORI */}
            <div style={card}>
                <h3>Tambah Kategori</h3>
                <form onSubmit={handleSubmit} style={{ marginTop: "10px" }}>
                    <input
                        type="text"
                        placeholder="Nama kategori"
                        value={form.nama_kategori}
                        onChange={(e) =>
                            setForm({ ...form, nama_kategori: e.target.value })
                        }
                        style={input}
                        required
                    />

                    <textarea
                        placeholder="Deskripsi"
                        value={form.deskripsi}
                        onChange={(e) =>
                            setForm({ ...form, deskripsi: e.target.value })
                        }
                        style={textarea}
                    ></textarea>

                    <button type="submit" style={buttonPrimary}>
                        Tambah Kategori
                    </button>
                </form>
            </div>

            {/* LIST KATEGORI */}
            <div style={{ marginTop: "20px" }}>
                <h3>Daftar Kategori</h3>

                <div style={card}>
                    <table style={table}>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Kategori</th>
                                <th>Deskripsi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            {kategori.length === 0 ? (
                                <tr>
                                    <td colSpan="4" style={{ textAlign: "center" }}>
                                        Tidak ada data
                                    </td>
                                </tr>
                            ) : (
                                kategori.map((k) => (
                                    <tr key={k.id}>
                                        <td>{k.id}</td>
                                        <td>{k.nama_kategori}</td>
                                        <td>{k.deskripsi}</td>
                                        <td>
                                            <button
                                                onClick={() => handleDelete(k.id)}
                                                style={buttonDelete}
                                            >
                                                Hapus
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </DashboardLayout>
    );
}

/* ------------------ STYLE ------------------ */

const card = {
    background: "white",
    padding: "20px",
    borderRadius: "10px",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
};

const input = {
    width: "100%",
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
};

const textarea = {
    width: "100%",
    padding: "10px",
    minHeight: "80px",
    marginBottom: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
};

const buttonPrimary = {
    background: "#4b49ac",
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
};

const buttonDelete = {
    background: "#e63946",
    color: "white",
    padding: "6px 12px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
};

const table = {
    width: "100%",
    borderCollapse: "collapse",
};

table.th = table.td = {
    padding: "10px",
    borderBottom: "1px solid #ddd",
};
