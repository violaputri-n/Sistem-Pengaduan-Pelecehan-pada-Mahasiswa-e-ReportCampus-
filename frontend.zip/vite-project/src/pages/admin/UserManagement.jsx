import { useEffect, useState } from "react";
import api from "../../api/axios";
import DashboardLayout from "../../components/DashboardLayout";

export default function UserManagement() {
    const [users, setUsers] = useState([]);
    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
        role: "mahasiswa",
    });

    function loadUsers() {
        api.get("/users").then(res => setUsers(res.data));
    }

    useEffect(() => {
        loadUsers();
    }, []);

    function handleSubmit(e) {
        e.preventDefault();
        api.post("/users", form).then(() => {
            loadUsers();
            setForm({ name: "", email: "", password: "", role: "mahasiswa" });
        });
    }

    function handleDelete(id) {
        api.delete(`/users/${id}`).then(() => loadUsers());
    }

    return (
        <DashboardLayout role="Admin">
            <h1 style={{ marginBottom: "20px" }}>Manajemen Pengguna</h1>

            {/* FORM TAMBAH USER */}
            <div style={card}>
                <h3>Tambah Pengguna Baru</h3>
                <form onSubmit={handleSubmit} style={formGrid}>
                    <input
                        type="text"
                        placeholder="Nama"
                        value={form.name}
                        onChange={e => setForm({ ...form, name: e.target.value })}
                        style={input}
                    />

                    <input
                        type="email"
                        placeholder="Email"
                        value={form.email}
                        onChange={e => setForm({ ...form, email: e.target.value })}
                        style={input}
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={form.password}
                        onChange={e => setForm({ ...form, password: e.target.value })}
                        style={input}
                    />

                    <select
                        value={form.role}
                        onChange={e => setForm({ ...form, role: e.target.value })}
                        style={input}
                    >
                        <option value="admin">Admin</option>
                        <option value="petugas">Petugas</option>
                        <option value="konselor">Konselor</option>
                        <option value="mahasiswa">Mahasiswa</option>
                    </select>

                    <button type="submit" style={btnPrimary}>
                        Simpan User
                    </button>
                </form>
            </div>

            {/* TABEL USER */}
            <div style={card}>
                <h3>Daftar Pengguna</h3>

                <table style={table}>
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        {users.map(u => (
                            <tr key={u.id}>
                                <td>{u.name}</td>
                                <td>{u.email}</td>
                                <td>{u.role}</td>
                                <td>
                                    <button onClick={() => handleDelete(u.id)} style={btnDanger}>
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </DashboardLayout>
    );
}

/* =============== STYLE =============== */

const card = {
    background: "white",
    padding: "20px",
    borderRadius: "10px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
    marginBottom: "20px",
};

const formGrid = {
    display: "grid",
    gridTemplateColumns: "repeat(2, 1fr)",
    gap: "15px",
    marginTop: "15px",
};

const input = {
    padding: "10px",
    borderRadius: "6px",
    border: "1px solid #ccc",
};

const btnPrimary = {
    gridColumn: "1 / span 2",
    padding: "10px",
    background: "#4b49ac",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
};

const btnDanger = {
    padding: "6px 12px",
    background: "#dc3545",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
};

const table = {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "15px",
};

table.th = table.td = {
    border: "1px solid #ddd",
    padding: "10px",
};
