import { Link } from "react-router-dom";
import DashboardLayout from "../../components/DashboardLayout";

export default function DashboardAdmin() {
    return (
        <DashboardLayout role="Admin">
            <h1>Selamat Datang Admin!</h1>
            <p>Ini adalah halaman utama Admin. Anda dapat mengelola seluruh sistem dari sini.</p>

            <div
                style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(3, 1fr)",
                    gap: "20px",
                    marginTop: "20px",
                }}
            >
                {/* Manajemen User */}
                <Link to="/admin/users" style={{ textDecoration: "none", color: "inherit" }}>
                    <div style={boxStyle}>
                        <h3>Manajemen User</h3>
                        <p>Kelola semua akun pengguna.</p>
                    </div>
                </Link>

                {/* Manajemen Kategori */}
                <Link to="/admin/kategori" style={{ textDecoration: "none", color: "inherit" }}>
                    <div style={boxStyle}>
                        <h3>Manajemen Kategori Kasus</h3>
                        <p>Kelola data kategori kasus.</p>
                    </div>
                </Link>

             
            </div>
        </DashboardLayout>
    );
}

const boxStyle = {
    background: "#f5f5f5",
    padding: "20px",
    borderRadius: "10px",
    boxShadow: "0 0 5px rgba(0,0,0,0.1)",
    cursor: "pointer",
};
