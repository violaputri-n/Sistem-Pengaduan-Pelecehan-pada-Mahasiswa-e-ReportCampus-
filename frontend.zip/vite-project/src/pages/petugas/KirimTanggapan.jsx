import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

export default function KirimTanggapan() {
    const { laporanId } = useParams(); // ✅ AMBIL DARI URL
    const navigate = useNavigate();

    const [tanggapan, setTanggapan] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async () => {
        if (!tanggapan.trim()) {
            alert("Tanggapan tidak boleh kosong");
            return;
        }

        setLoading(true);

        try {
            const response = await axios.post(
                `http://localhost:8000/api/petugas/laporan/${laporanId}/tanggapan`,
                {
                    tanggapan: tanggapan
                },
                {
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                    }
                }
            );

            console.log("Response API:", response.data);

            alert("Tanggapan berhasil dikirim");

            // 🔁 Kembali ke daftar laporan
            navigate("/petugas/daftar-laporan");

        } catch (error) {
            console.error("ERROR:", error.response || error);

            if (error.response) {
                alert(
                    `Error ${error.response.status}: ` +
                    JSON.stringify(error.response.data)
                );
            } else {
                alert("Server tidak merespon");
            }

        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h2>Kirim Tanggapan untuk Laporan #{laporanId}</h2>

            <textarea
                value={tanggapan}
                onChange={(e) => setTanggapan(e.target.value)}
                placeholder="Tulis tanggapan..."
                style={{
                    width: "100%",
                    height: "150px",
                    padding: "10px"
                }}
            />

            <div style={{ marginTop: "20px" }}>
                <button
                    onClick={handleSubmit}
                    disabled={loading}
                    style={{
                        padding: "8px 16px",
                        background: "#28a745",
                        color: "white",
                        border: "none",
                        borderRadius: "5px",
                        marginRight: "10px"
                    }}
                >
                    {loading ? "Mengirim..." : "Kirim"}
                </button>

                <button
                    onClick={() => navigate("/petugas/daftar-laporan")}
                    style={{
                        padding: "8px 16px",
                        background: "#6c757d",
                        color: "white",
                        border: "none",
                        borderRadius: "5px"
                    }}
                >
                    Kembali
                </button>
            </div>
        </div>
    );
}
