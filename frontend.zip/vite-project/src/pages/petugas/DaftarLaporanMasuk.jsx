import { useEffect, useState } from "react";
import axios from "axios";

export default function DaftarLaporanMasuk() {
    const [laporan, setLaporan] = useState([]);
    const [kategoriMap, setKategoriMap] = useState({});
    const [selectedLaporan, setSelectedLaporan] = useState(null);
    const [showTanggapan, setShowTanggapan] = useState(false);
    const [tanggapan, setTanggapan] = useState("");
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);

    useEffect(() => {
        fetchAllData();
    }, []);

    const fetchAllData = async () => {
        try {
            const [laporanRes, kategoriRes] = await Promise.all([
                axios.get("http://localhost:8000/api/petugas/laporan-masuk"),
                axios.get("http://localhost:8000/api/kategori"),
            ]);

            const laporanData = Array.isArray(laporanRes.data)
                ? laporanRes.data
                : laporanRes.data?.data ?? [];

            setLaporan(laporanData);

            const kategoriObj = {};
            kategoriRes.data.forEach((k) => {
                kategoriObj[k.id] = k.nama_kategori;
            });

            setKategoriMap(kategoriObj);

        } catch (err) {
            console.error("Gagal mengambil data:", err);
            setLaporan([]);
        } finally {
            setLoading(false);
        }
    };

    const openDetail = (item) => {
        setSelectedLaporan(item);
        setShowTanggapan(false);
        setTanggapan("");
    };

    const closeDetail = () => {
        setSelectedLaporan(null);
        setShowTanggapan(false);
        setTanggapan("");
    };

    const handleKirimTanggapan = async () => {
        if (!tanggapan.trim()) {
            alert("Tanggapan tidak boleh kosong");
            return;
        }

        setSending(true);

        try {
            await axios.post(
                `http://localhost:8000/api/petugas/laporan/${selectedLaporan.id}/tanggapan`,
                { tanggapan },
                {
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                    },
                }
            );

            alert("Tanggapan berhasil dikirim");

            closeDetail();
            fetchAllData(); 

        } catch (err) {
            console.error(err);
            alert("Gagal mengirim tanggapan");
        } finally {
            setSending(false);
        }
    };

    if (loading) {
        return <p>Loading data laporan...</p>;
    }

    return (
        <div>
            <h1>Daftar Laporan Masuk</h1>

            <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 20 }}>
                <thead>
                    <tr>
                        <th style={thStyle}>#</th>
                        <th style={thStyle}>Mahasiswa</th>
                        <th style={thStyle}>Kategori</th>
                        <th style={thStyle}>Status</th>
                        <th style={thStyle}>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    {laporan.length === 0 ? (
                        <tr>
                            <td colSpan="5" style={tdStyle}>Tidak ada laporan</td>
                        </tr>
                    ) : (
                        laporan.map((item, index) => (
                            <tr key={item.id}>
                                <td style={tdStyle}>{index + 1}</td>
                                <td style={tdStyle}>{item.mahasiswa_nama ?? "-"}</td>
                                <td style={tdStyle}>
                                    {kategoriMap[item.kategori_kasus] ?? "-"}
                                </td>
                                <td style={tdStyle}>{item.status}</td>
                                <td style={tdStyle}>
                                    <button
                                        style={btnDetail}
                                        onClick={() => openDetail(item)}
                                    >
                                        Detail
                                    </button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>

            {selectedLaporan && (
                <div style={overlay}>
                    <div style={popup}>
                        <h2>Detail Laporan #{selectedLaporan.id}</h2>

                        <p><b>Mahasiswa:</b> {selectedLaporan.mahasiswa_nama}</p>
                        <p><b>Kategori:</b> {kategoriMap[selectedLaporan.kategori_kasus]}</p>
                        <p><b>Deskripsi:</b> {selectedLaporan.deskripsi}</p>
                        <p><b>Waktu:</b> {selectedLaporan.waktu_kejadian}</p>
                        <p><b>Lokasi:</b> {selectedLaporan.lokasi}</p>
                        <p><b>Status:</b> {selectedLaporan.status}</p>

                        {!showTanggapan ? (
                            <div style={{ marginTop: 20, textAlign: "right" }}>
                                <button
                                    style={btnPrimary}
                                    onClick={() => setShowTanggapan(true)}
                                >
                                    Tindak Lanjut
                                </button>
                                <button style={btnClose} onClick={closeDetail}>
                                    Tutup
                                </button>
                            </div>
                        ) : (
                            <>
                                <hr />
                                <h3>Kirim Tanggapan</h3>
                                <textarea
                                    value={tanggapan}
                                    onChange={(e) => setTanggapan(e.target.value)}
                                    placeholder="Tulis tanggapan..."
                                    style={{
                                        width: "100%",
                                        height: 120,
                                        padding: 10,
                                        marginTop: 10
                                    }}
                                />

                                <div style={{ marginTop: 15, textAlign: "right" }}>
                                    <button
                                        style={btnPrimary}
                                        onClick={handleKirimTanggapan}
                                        disabled={sending}
                                    >
                                        {sending ? "Mengirim..." : "Kirim"}
                                    </button>
                                    <button
                                        style={btnClose}
                                        onClick={() => setShowTanggapan(false)}
                                    >
                                        Batal
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}


const thStyle = {
    border: "1px solid #ddd",
    padding: 8,
    background: "#f2f2f2",
};

const tdStyle = {
    border: "1px solid #ddd",
    padding: 8,
    textAlign: "center",
};

const btnDetail = {
    padding: "6px 12px",
    background: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: 4,
    cursor: "pointer",
};

const overlay = {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.5)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 999,
};

const popup = {
    width: 520,
    background: "#fff",
    padding: 20,
    borderRadius: 8,
};

const btnPrimary = {
    padding: "8px 16px",
    background: "#28a745",
    color: "#fff",
    border: "none",
    borderRadius: 5,
    marginRight: 10,
};

const btnClose = {
    padding: "8px 16px",
    background: "#6c757d",
    color: "#fff",
    border: "none",
    borderRadius: 5,
};
