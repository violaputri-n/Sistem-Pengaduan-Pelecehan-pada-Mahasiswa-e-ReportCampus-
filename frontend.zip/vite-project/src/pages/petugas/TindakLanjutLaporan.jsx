export default function TindakLanjutLaporan() {
    return (
        <div>
            <h2>Halaman Tindak Lanjut Laporan</h2>
        </div>
    );
}
