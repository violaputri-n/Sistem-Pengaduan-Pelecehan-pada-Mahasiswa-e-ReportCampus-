import { useState, useEffect } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import axios from "axios";
import DaftarLaporanMasuk from "./DaftarLaporanMasuk";
import TindakLanjutLaporan from "./TindakLanjutLaporan";
import KirimTanggapan from "./KirimTanggapan";
import "../../styles/petugas.css";

export default function DashboardPetugas() {
    const [activeTab, setActiveTab] = useState("home");
    const [selectedLaporanId, setSelectedLaporanId] = useState(null);
    const [currentAction, setCurrentAction] = useState(null);
    const [showModal, setShowModal] = useState(false);

    // ================= REAL STATISTICS FROM DB =================
    const [stats, setStats] = useState({
        total_laporan: 0,
        laporan_pending: 0,
        laporan_resolved: 0,
    });

    const [recentLaporan, setRecentLaporan] = useState([]);

    useEffect(() => {
        if (activeTab === "home") {
            fetchRecentLaporan();
            fetchStats(); // 🔥 ambil statistik real
        }
    }, [activeTab]);

    // ================= FETCH STATISTIK =================
    const fetchStats = async () => {
        try {
            const token = localStorage.getItem("token");
            const headers = { Authorization: `Bearer ${token}` };

            const res = await axios.get(
                "http://localhost:8000/api/petugas/statistik-laporan",
                { headers }
            );

            setStats({
                total_laporan: res.data.total,
                laporan_pending: res.data.pending,
                laporan_resolved: res.data.resolved,
            });
        } catch (error) {
            console.error("Gagal mengambil statistik laporan:", error);
        }
    };

    // ================= FETCH RECENT LAPORAN =================
    const fetchRecentLaporan = async () => {
        try {
            const token = localStorage.getItem("token");
            const headers = { Authorization: `Bearer ${token}` };

            const res = await axios.get(
                "http://localhost:8000/api/petugas/laporan-masuk?limit=5",
                { headers }
            );

            setRecentLaporan(res.data.data || []);
        } catch (error) {
            console.warn("API laporan-masuk gagal.");
            setRecentLaporan([]);
        }
    };

    const handleLaporanAction = (id, action) => {
        setSelectedLaporanId(id);
        setCurrentAction(action);
        setShowModal(true);
    };

    const handleBackFromAction = () => {
        setShowModal(false);
        setSelectedLaporanId(null);
        setCurrentAction(null);
        fetchRecentLaporan();
        fetchStats();
    };

    return (
        <DashboardLayout role="Petugas">
            <div className="petugas-container">

                {/* Tabs */}
                <div className="tabs-navigation">
                    <button
                        className={`tab-btn ${activeTab === "home" ? "active" : ""}`}
                        onClick={() => setActiveTab("home")}
                    >
                        🏠 Beranda
                    </button>

                    <button
                        className={`tab-btn ${activeTab === "daftar" ? "active" : ""}`}
                        onClick={() => setActiveTab("daftar")}
                    >
                        📋 Daftar Laporan
                    </button>
                </div>

                {/* Content */}
                <div className="tab-content">
                    {activeTab === "home" && (
                        <HomeTab
                            stats={stats}
                            recentLaporan={recentLaporan}
                            onSelectLaporan={handleLaporanAction}
                        />
                    )}

                    {activeTab === "daftar" && (
                        <DaftarLaporanMasuk onSelectAction={handleLaporanAction} />
                    )}

                    {/* Modal Action */}
                    {showModal && (
                        <div className="modal-overlay" onClick={handleBackFromAction}>
                            <div
                                className="modal-content modal-lg"
                                onClick={(e) => e.stopPropagation()}
                            >
                                <div className="modal-header">
                                    <h2>
                                        {currentAction === "tanggapan"
                                            ? "Kirim Tanggapan"
                                            : "Tindak Lanjut Laporan"}
                                    </h2>

                                    <button className="modal-close" onClick={handleBackFromAction}>
                                        ×
                                    </button>
                                </div>

                                <div className="modal-body">
                                    {currentAction === "tindaklanjut" && (
                                        <TindakLanjutLaporan
                                            laporanId={selectedLaporanId}
                                            onBack={handleBackFromAction}
                                            onSuccess={handleBackFromAction}
                                        />
                                    )}

                                    {currentAction === "tanggapan" && (
                                        <KirimTanggapan
                                            laporanId={selectedLaporanId}
                                            onBack={handleBackFromAction}
                                            onSuccess={handleBackFromAction}
                                        />
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </DashboardLayout>
    );
}

// ================= HOME TAB =================

function HomeTab({ stats, recentLaporan, onSelectLaporan }) {
    return (
        <>
            <div className="petugas-header">
                <h1>Selamat Datang Petugas 👋</h1>
                <p>Kelola semua laporan mahasiswa dengan cepat dan tepat.</p>
            </div>

            <div className="stats-grid">
                <div className="stat-card">
                    <h3>{stats.total_laporan}</h3>
                    <p>Total Laporan</p>
                </div>
                <div className="stat-card">
                    <h3>{stats.laporan_pending}</h3>
                    <p>Pending</p>
                </div>
                <div className="stat-card">
                    <h3>{stats.laporan_resolved}</h3>
                    <p>Resolved</p>
                </div>
            </div>

            <div className="recent-section">
                <h2>Laporan Terbaru</h2>

                {recentLaporan.length === 0 ? (
                    <p>Tidak ada laporan terbaru</p>
                ) : (
                    recentLaporan.map((laporan) => (
                        <div key={laporan.id} className="recent-item">
                            <h4>Laporan #{laporan.id}</h4>
                            <p>
                                {laporan.mahasiswa_nama} — {laporan.kategori_kasus}
                            </p>
                            <button
                                className="btn btn-primary"
                                onClick={() => onSelectLaporan(laporan.id, "tanggapan")}
                            >
                                Kirim Tanggapan
                            </button>
                        </div>
                    ))
                )}
            </div>
        </>
    );
}
