import { useState, useEffect } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import axios from "axios";

import BuatLaporanKasus from "./BuatLaporanKasus";
import StatusLaporan from "./StatusLaporan";
import RiwayatLaporan from "./RiwayatLaporan";
import KonsultasiOnline from "./KonsultasiOnline";
import ChatKonselor from "./ChatKonselor";
import Notifikasi from "./NotifikasiMahasiswa";

import "../../styles/mahasiswa.css";

export default function DashboardMahasiswa() {
    const [activeTab, setActiveTab] = useState("home");
    const [selectedKonsultasiId, setSelectedKonsultasiId] = useState(null);

    const [stats, setStats] = useState({
        total_laporan: 0,
        laporan_pending: 0,
        konsultasi_menunggu: 0,
        notifikasi_belum_baca: 0,
    });

    const [recentLaporan, setRecentLaporan] = useState([]);
    const [recentKonsultasi, setRecentKonsultasi] = useState([]);

    useEffect(() => {
        if (activeTab === "home") {
            fetchDashboardData();
        }
    }, [activeTab]);

    const fetchDashboardData = async () => {
        try {
            const token = localStorage.getItem("token");
            const headers = {
                Authorization: `Bearer ${token}`,
            };

            const statsRes = await axios.get(
                "http://localhost:8000/api/mahasiswa/dashboard/stats",
                { headers }
            );
            setStats(statsRes.data);

            const laporanRes = await axios.get(
                "http://localhost:8000/api/mahasiswa/laporan-terbaru?limit=3",
                { headers }
            );
            setRecentLaporan(laporanRes.data?.data || []);

            const konsultasiRes = await axios.get(
                "http://localhost:8000/api/mahasiswa/konsultasi?limit=3",
                { headers }
            );
            setRecentKonsultasi(konsultasiRes.data?.data || []);
        } catch (error) {
            console.error("Dashboard error:", error);
        }
    };

    return (
        <DashboardLayout role="Mahasiswa">
            <div className="mahasiswa-container">

                {/* ================= TAB NAV ================= */}
                <div className="tabs-navigation">
                    {[
                        ["home", "🏠 Beranda"],
                        ["buat-laporan", "📝 Buat Laporan"],
                        ["riwayat-laporan", "📚 Riwayat"],
                        ["konsultasi", "💬 Konsultasi"],
                        ["notifikasi", "🔔 Notifikasi"],
                    ].map(([key, label]) => (
                        <button
                            key={key}
                            className={`tab-btn ${activeTab === key ? "active" : ""}`}
                            onClick={() => setActiveTab(key)}
                        >
                            {label}
                        </button>
                    ))}
                </div>

                {/* ================= CONTENT ================= */}
                <div className="tab-content">
                    {activeTab === "home" && (
                        <HomeTab
                            stats={stats}
                            recentLaporan={recentLaporan}
                            recentKonsultasi={recentKonsultasi}
                            onTabChange={setActiveTab}
                        />
                    )}

                    {activeTab === "buat-laporan" && (
                        <BuatLaporanKasus
                            onSuccess={() => setActiveTab("status-laporan")}
                        />
                    )}

                    {activeTab === "status-laporan" && <StatusLaporan />}
                    {activeTab === "riwayat-laporan" && <RiwayatLaporan />}

                    {activeTab === "konsultasi" && (
                        <KonsultasiOnline
                            onSelectChat={(id) => {
                                setSelectedKonsultasiId(id);
                                setActiveTab("chat");
                            }}
                        />
                    )}

                    {activeTab === "chat" && (
                        <ChatKonselor
                            konsultasiId={selectedKonsultasiId}
                            onBack={() => setActiveTab("konsultasi")}
                        />
                    )}

                    {activeTab === "notifikasi" && <Notifikasi />}
                </div>
            </div>
        </DashboardLayout>
    );
}


function HomeTab({ stats, recentLaporan, recentKonsultasi, onTabChange }) {
    return (
        <>
            <div className="mahasiswa-header">
                <h1>Dashboard Mahasiswa</h1>
                <p>Ringkasan laporan & konsultasi Anda</p>
            </div>

            {/* QUICK STATS */}
            <div className="stats-grid">
                <StatCard
                    icon="📋"
                    label="Total Laporan"
                    value={stats.total_laporan}
                    onClick={() => onTabChange("riwayat-laporan")}
                />
                <StatCard
                    icon="⏳"
                    label="Pending"
                    value={stats.laporan_pending}
                    onClick={() => onTabChange("status-laporan")}
                />
                <StatCard
                    icon="💬"
                    label="Konsultasi"
                    value={stats.konsultasi_menunggu}
                    onClick={() => onTabChange("konsultasi")}
                />
                <StatCard
                    icon="🔔"
                    label="Notifikasi"
                    value={stats.notifikasi_belum_baca}
                    onClick={() => onTabChange("notifikasi")}
                />
            </div>

            {/* QUICK ACTION */}
            <div className="menu-section">
                <h2>Aksi Cepat</h2>
                <div className="menu-grid">
                    <QuickMenu icon="📝" title="Buat Laporan" onClick={() => onTabChange("buat-laporan")} />
                    <QuickMenu icon="📊" title="Cek Status" onClick={() => onTabChange("status-laporan")} />
                    <QuickMenu icon="💬" title="Konsultasi" onClick={() => onTabChange("konsultasi")} />
                </div>
            </div>

            {/* RECENT ACTIVITY */}
            <div className="activity-section">
                <ActivityColumn
                    title="Laporan Terbaru"
                    data={recentLaporan}
                    emptyText="Belum ada laporan"
                    onClick={() => onTabChange("status-laporan")}
                />
                <ActivityColumn
                    title="Konsultasi Terbaru"
                    data={recentKonsultasi}
                    emptyText="Belum ada konsultasi"
                    onClick={() => onTabChange("konsultasi")}
                />
            </div>
        </>
    );
}

const StatCard = ({ icon, label, value, onClick }) => {
    const isTotal = label === "Total Laporan";

    return (
        <div
            className="stat-card"
            onClick={onClick}
            style={{
                cursor: "pointer",
                backgroundColor: isTotal ? "#1e40af" : "#f3f4f6",
                borderRadius: "16px",
                padding: "20px",
                boxShadow: "0 6px 16px rgba(0,0,0,0.1)",
            }}
        >
            <div
                style={{
                    fontSize: "36px",
                    marginBottom: "10px",
                    color: isTotal ? "#ffffff" : "#111827",
                }}
            >
                {icon}
            </div>

            <h3
                style={{
                    fontSize: "36px",
                    fontWeight: "800",
                    margin: 0,
                    color: isTotal ? "#ffffff" : "#111827",
                }}
            >
                {value}
            </h3>

            <p
                style={{
                    marginTop: "6px",
                    fontSize: "14px",
                    fontWeight: "600",
                    color: isTotal ? "#e5e7eb" : "#374151",
                }}
            >
                {label}
            </p>
        </div>
    );
};

const QuickMenu = ({ icon, title, onClick }) => (
    <div className="menu-card" onClick={onClick} style={{ cursor: "pointer" }}>
        <div className="menu-icon">{icon}</div>
        <h3>{title}</h3>
        <button className="btn btn-primary">Buka</button>
    </div>
);

const ActivityColumn = ({ title, data, emptyText, onClick }) => (
    <div className="activity-column">
        <h2>{title}</h2>

        {data.length === 0 ? (
            <p>{emptyText}</p>
        ) : (
            data.map((item) => (
                <div
                    key={item.id}
                    className="activity-item laporan-card"
                    onClick={onClick}
                    style={{
                        cursor: "pointer",
                        padding: "14px",
                        borderRadius: "12px",
                        marginBottom: "12px",
                        background: "#f9fafb",
                        borderLeft: `6px solid ${
                            item.status === "resolved"
                                ? "#16a34a"
                                : item.status === "pending"
                                ? "#f59e0b"
                                : "#2563eb"
                        }`,
                    }}
                >
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <strong>{item.kategori_kasus}</strong>
                        <span
                            style={{
                                fontSize: "12px",
                                padding: "4px 10px",
                                borderRadius: "999px",
                                background:
                                    item.status === "resolved"
                                        ? "#dcfce7"
                                        : item.status === "pending"
                                        ? "#fef3c7"
                                        : "#dbeafe",
                                color:
                                    item.status === "resolved"
                                        ? "#166534"
                                        : item.status === "pending"
                                        ? "#92400e"
                                        : "#1e40af",
                            }}
                        >
                            {item.status.toUpperCase()}
                        </span>
                    </div>

                    <p style={{ margin: "6px 0", fontSize: "14px", color: "#374151" }}>
                        {item.deskripsi}
                    </p>

                    <small style={{ color: "#6b7280" }}>
                        📍 {item.lokasi} <br />
                        🕒{" "}
                        {new Date(item.waktu_kejadian).toLocaleString("id-ID")}
                    </small>
                </div>
            ))
        )}
    </div>
);
