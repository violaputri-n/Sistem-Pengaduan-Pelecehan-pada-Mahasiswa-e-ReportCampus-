import { useState, useEffect } from "react";
import axios from "axios";
import "../../styles/mahasiswa.css";

export default function KonsultasiOnline({ onSelectChat = () => {} }) {
    const [konsultasi, setKonsultasi] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [selectedKonsultasi, setSelectedKonsultasi] = useState(null);
    const [formData, setFormData] = useState({
        topik: "",
        deskripsi: "",
    });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        fetchKonsultasi();
    }, []);

    const fetchKonsultasi = async () => {
        try {
            const response = await axios.get(
                "http://localhost:8000/api/mahasiswa/konsultasi",
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );
            setKonsultasi(response.data.data || response.data);
        } catch (error) {
            console.error("Error fetching konsultasi:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);

        try {
            const response = await axios.post(
                "http://localhost:8000/api/mahasiswa/konsultasi",
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );

            setKonsultasi([response.data.data, ...konsultasi]);
            setFormData({
                topik: "",
                deskripsi: "",
            });
            setShowModal(false);
            alert("Permintaan konsultasi berhasil dibuat!");
        } catch (error) {
            alert(
                error.response?.data?.message ||
                    "Terjadi kesalahan saat membuat konsultasi"
            );
        } finally {
            setSubmitting(false);
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: "#ffc107",
            approved: "#28a745",
            ongoing: "#17a2b8",
            completed: "#6c757d",
            rejected: "#dc3545",
        };
        return colors[status] || "#6c757d";
    };

    const getStatusLabel = (status) => {
        const labels = {
            pending: "Menunggu",
            approved: "Diterima",
            ongoing: "Sedang Berlangsung",
            completed: "Selesai",
            rejected: "Ditolak",
        };
        return labels[status] || status;
    };

    if (loading) {
        return (
            <div className="mahasiswa-container">
                <p className="loading">Memuat data konsultasi...</p>
            </div>
        );
    }

    return (
        <>
            <div className="mahasiswa-header">
                <h1>Konsultasi Online</h1>
                <p>Ajukan konsultasi dengan konselor profesional kami</p>
            </div>

            <div className="action-buttons">
                <button
                    className="btn btn-primary"
                    onClick={() => setShowModal(true)}
                >
                    + Ajukan Konsultasi
                </button>
            </div>

            {konsultasi.length === 0 ? (
                <div className="empty-state">
                    <p>Belum ada konsultasi yang diajukan</p>
                </div>
            ) : (
                <div className="konsultasi-grid">
                    {konsultasi.map((k) => (
                        <div
                            key={k.id}
                            className="konsultasi-card"
                            onClick={() => setSelectedKonsultasi(k)}
                        >
                            <div className="konsultasi-header">
                                <h3>{k.topik}</h3>
                                <span
                                    style={{
                                        display: "inline-block",
                                        padding: "6px 12px",
                                        borderRadius: "4px",
                                        backgroundColor: getStatusColor(k.status),
                                        color: "white",
                                        fontSize: "12px",
                                    }}
                                >
                                    {getStatusLabel(k.status)}
                                </span>
                            </div>

                            <div className="konsultasi-info">
                                <p>
                                    <strong>Tanggal:</strong>{" "}
                                    {new Date(k.created_at).toLocaleDateString("id-ID")}
                                </p>
                                <p className="deskripsi">
                                    {k.deskripsi ? k.deskripsi.substring(0, 80) : "-"}...
                                </p>
                            </div>

                            {k.status === "approved" || k.status === "ongoing" ? (
                                <button
                                    className="btn btn-success"
                                    onClick={() => onSelectChat(k.id)}
                                >
                                    Mulai Chat
                                </button>
                            ) : (
                                <button className="btn btn-detail">Lihat Detail</button>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {showModal && (
                <div className="modal-overlay" onClick={() => setShowModal(false)}>
                    <div
                        className="modal-content"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="modal-header">
                            <h2>Ajukan Konsultasi Baru</h2>
                            <button
                                className="close-btn"
                                onClick={() => setShowModal(false)}
                            >
                                ×
                            </button>
                        </div>

                        <form onSubmit={handleSubmit} className="form-konsultasi">
                            <div className="form-group">
                                <label htmlFor="topik">
                                    Topik Konsultasi <span className="required">*</span>
                                </label>
                                <input
                                    type="text"
                                    id="topik"
                                    name="topik"
                                    value={formData.topik}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Contoh: Stress akademik"
                                    className="form-control"
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="deskripsi">
                                    Deskripsi Singkat <span className="required">*</span>
                                </label>
                                <textarea
                                    id="deskripsi"
                                    name="deskripsi"
                                    value={formData.deskripsi}
                                    onChange={handleInputChange}
                                    required
                                    rows="4"
                                    placeholder="Jelaskan apa yang ingin Anda konsultasikan..."
                                    className="form-control"
                                ></textarea>
                            </div>

                            <div className="modal-footer">
                                <button
                                    type="submit"
                                    disabled={submitting}
                                    className="btn btn-primary"
                                >
                                    {submitting ? "Mengirim..." : "Ajukan"}
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-secondary"
                                    onClick={() => setShowModal(false)}
                                >
                                    Batal
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {selectedKonsultasi && (
                <div
                    className="modal-overlay"
                    onClick={() => setSelectedKonsultasi(null)}
                >
                    <div
                        className="modal-content"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="modal-header">
                            <h2>Detail Konsultasi</h2>
                            <button
                                className="close-btn"
                                onClick={() => setSelectedKonsultasi(null)}
                            >
                                ×
                            </button>
                        </div>

                        <div className="modal-body">
                            <div className="detail-grid">
                                <div className="detail-item">
                                    <label>Topik</label>
                                    <p>{selectedKonsultasi.topik}</p>
                                </div>

                                <div className="detail-item">
                                    <label>Status</label>
                                    <div
                                        style={{
                                            display: "inline-block",
                                            padding: "6px 12px",
                                            borderRadius: "4px",
                                            backgroundColor: getStatusColor(
                                                selectedKonsultasi.status
                                            ),
                                            color: "white",
                                        }}
                                    >
                                        {getStatusLabel(selectedKonsultasi.status)}
                                    </div>
                                </div>

                                <div className="detail-item full-width">
                                    <label>Deskripsi</label>
                                    <p>{selectedKonsultasi.deskripsi || "-"}</p>
                                </div>
                            </div>
                        </div>

                        <div className="modal-footer">
                            <button
                                className="btn btn-secondary"
                                onClick={() => setSelectedKonsultasi(null)}
                            >
                                Tutup
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}