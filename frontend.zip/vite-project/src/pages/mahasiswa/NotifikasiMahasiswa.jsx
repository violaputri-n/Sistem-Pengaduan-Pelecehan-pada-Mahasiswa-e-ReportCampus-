import { useEffect, useState } from "react";
import api from "../../api/axios";

export default function NotifikasiMahasiswa() {
    const [data, setData] = useState([]);

    useEffect(() => {
        api.get("/mahasiswa/notifikasi").then(res => {
            setData(res.data);
        });
    }, []);

    return (
        <div>
            <h3>Notifikasi</h3>
            {data.length === 0 && <p>Tidak ada notifikasi</p>}

            {data.map(n => (
                <div
                    key={n.id}
                    style={{
                        padding: 10,
                        background: n.is_read ? "#f1f1f1" : "#e8f0ff",
                        marginBottom: 8,
                        borderRadius: 6
                    }}
                >
                    <strong>{n.title}</strong>
                    <p>{n.message}</p>
                </div>
            ))}
        </div>
    );
}
