import { useState, useEffect } from "react";
import axios from "axios";
import "../../styles/mahasiswa.css";

export default function StatusLaporan() {
    const [laporan, setLaporan] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedLaporan, setSelectedLaporan] = useState(null);
    const [filterStatus, setFilterStatus] = useState("semua");

    useEffect(() => {
        fetchLaporan();
    }, []);

    const fetchLaporan = async () => {
        try {
            const response = await axios.get(
                "http://localhost:8000/api/mahasiswa/laporan-kasus",
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );
            setLaporan(response.data.data || response.data);
            setLoading(false);
        } catch (error) {
            console.error("Error fetching laporan:", error);
            setLoading(false);
        }
    };

    const getStatusBadge = (status) => {
        const statusMap = {
            pending: { class: "badge-warning", label: "Pending" },
            verified: { class: "badge-info", label: "Diverifikasi" },
            under_review: {
                class: "badge-secondary",
                label: "Dalam Pemeriksaan",
            },
            resolved: { class: "badge-success", label: "Selesai" },
            rejected: { class: "badge-danger", label: "Ditolak" },
        };
        return statusMap[status] || { class: "badge-dark", label: status };
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: "#ffc107",
            verified: "#17a2b8",
            under_review: "#6c757d",
            resolved: "#28a745",
            rejected: "#dc3545",
        };
        return colors[status] || "#6c757d";
    };

    const filteredLaporan =
        filterStatus === "semua"
            ? laporan
            : laporan.filter((l) => l.status === filterStatus);

    if (loading) {
        return (
            <div className="mahasiswa-container">
                <p className="loading">Memuat data laporan...</p>
            </div>
        );
    }

    return (
        <>
            <div className="mahasiswa-header">
                    <h1>Status Laporan Kasus</h1>
                    <p>Pantau status laporan kasus yang telah Anda buat</p>
                </div>

                <div className="filter-section">
                    <div className="filter-group">
                        <label htmlFor="filterStatus">Filter Status:</label>
                        <select
                            id="filterStatus"
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            className="form-control"
                        >
                            <option value="semua">Semua Status</option>
                            <option value="pending">Pending</option>
                            <option value="verified">Diverifikasi</option>
                            <option value="under_review">
                                Dalam Pemeriksaan
                            </option>
                            <option value="resolved">Selesai</option>
                            <option value="rejected">Ditolak</option>
                        </select>
                    </div>
                </div>

                {filteredLaporan.length === 0 ? (
                    <div className="empty-state">
                        <p>Belum ada laporan kasus</p>
                        <a href="/mahasiswa/buat-laporan" className="btn btn-primary">
                            Buat Laporan Pertama
                        </a>
                    </div>
                ) : (
                    <div className="laporan-grid">
                        {filteredLaporan.map((l) => (
                            <div
                                key={l.id}
                                className="laporan-card"
                                onClick={() => setSelectedLaporan(l)}
                            >
                                <div className="laporan-header">
                                    <h3>Laporan #{l.id}</h3>
                                    <span
                                        className={`badge ${
                                            getStatusBadge(l.status).class
                                        }`}
                                    >
                                        {
                                            getStatusBadge(l.status).label
                                        }
                                    </span>
                                </div>

                                <div className="laporan-info">
                                    <p>
                                        <strong>Kategori:</strong> {l.kategori_kasus}
                                    </p>
                                    <p>
                                        <strong>Tanggal Lapor:</strong>{" "}
                                        {new Date(l.created_at).toLocaleDateString(
                                            "id-ID"
                                        )}
                                    </p>
                                    <p className="deskripsi">
                                        {l.deskripsi.substring(0, 100)}...
                                    </p>
                                </div>

                                <button
                                    className="btn btn-detail"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setSelectedLaporan(l);
                                    }}
                                >
                                    Lihat Detail
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                {selectedLaporan && (
                    <div className="modal-overlay" onClick={() => setSelectedLaporan(null)}>
                        <div
                            className="modal-content"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="modal-header">
                                <h2>Detail Laporan #{selectedLaporan.id}</h2>
                                <button
                                    className="close-btn"
                                    onClick={() => setSelectedLaporan(null)}
                                >
                                    ×
                                </button>
                            </div>

                            <div className="modal-body">
                                <div className="detail-grid">
                                    <div className="detail-item">
                                        <label>Status</label>
                                        <div
                                            style={{
                                                display: "inline-block",
                                                padding: "6px 12px",
                                                borderRadius: "4px",
                                                backgroundColor:
                                                    getStatusColor(
                                                        selectedLaporan.status
                                                    ),
                                                color: "white",
                                            }}
                                        >
                                            {
                                                getStatusBadge(
                                                    selectedLaporan.status
                                                ).label
                                            }
                                        </div>
                                    </div>

                                    <div className="detail-item">
                                        <label>Kategori</label>
                                        <p>{selectedLaporan.kategori_kasus}</p>
                                    </div>

                                    <div className="detail-item">
                                        <label>Waktu Kejadian</label>
                                        <p>
                                            {new Date(
                                                selectedLaporan.waktu_kejadian
                                            ).toLocaleDateString("id-ID", {
                                                year: "numeric",
                                                month: "long",
                                                day: "numeric",
                                                hour: "2-digit",
                                                minute: "2-digit",
                                            })}
                                        </p>
                                    </div>

                                    <div className="detail-item">
                                        <label>Lokasi</label>
                                        <p>{selectedLaporan.lokasi}</p>
                                    </div>

                                    <div className="detail-item full-width">
                                        <label>Deskripsi</label>
                                        <p>{selectedLaporan.deskripsi}</p>
                                    </div>

                                    {selectedLaporan.catatan && (
                                        <div className="detail-item full-width">
                                            <label>Catatan Konselor</label>
                                            <p>{selectedLaporan.catatan}</p>
                                        </div>
                                    )}

                                    <div className="detail-item">
                                        <label>Tanggal Lapor</label>
                                        <p>
                                            {new Date(
                                                selectedLaporan.created_at
                                            ).toLocaleDateString("id-ID")}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="modal-footer">
                                {selectedLaporan.status === "pending" && (
                                    <button
                                        className="btn btn-danger"
                                        onClick={() => {
                                            // Implement delete function
                                            setSelectedLaporan(null);
                                        }}
                                    >
                                        Batalkan Laporan
                                    </button>
                                )}
                                <button
                                    className="btn btn-secondary"
                                    onClick={() => setSelectedLaporan(null)}
                                >
                                    Tutup
                                </button>
                            </div>
                        </div>
                    </div>
                )}
        </>
    );
}
