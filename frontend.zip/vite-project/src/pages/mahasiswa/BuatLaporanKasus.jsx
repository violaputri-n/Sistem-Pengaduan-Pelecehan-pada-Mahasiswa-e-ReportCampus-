import { useState, useEffect } from "react";
import api from "../../api/axios";
import "../../styles/mahasiswa.css";

export default function BuatLaporanKasus({ onSuccess }) {
    const [formData, setFormData] = useState({
        kategori_kasus: "",
        deskripsi: "",
        waktu_kejadian: "",
        lokasi: "",
        bukti_file: null,
    });

    const [kategoriList, setKategoriList] = useState([]); 
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const [messageType, setMessageType] = useState("");

    useEffect(() => {
        const fetchKategori = async () => {
            try {
                const response = await api.get("/kategori"); 
                setKategoriList(response.data);
            } catch (error) {
                console.error("Gagal mengambil kategori:", error);
            }
        };

        fetchKategori();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleFileChange = (e) => {
        setFormData({
            ...formData,
            bukti_file: e.target.files[0],
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            const data = new FormData();
            data.append("kategori_kasus", formData.kategori_kasus);
            data.append("deskripsi", formData.deskripsi);
            data.append("waktu_kejadian", formData.waktu_kejadian);
            data.append("lokasi", formData.lokasi);
            if (formData.bukti_file) {
                data.append("bukti_file", formData.bukti_file);
            }

            const response = await api.post("/mahasiswa/laporan-kasus", data);

            setMessageType("success");
            setMessage("Laporan kasus berhasil dibuat! ID Laporan: " + response.data.id);

            setFormData({
                kategori_kasus: "",
                deskripsi: "",
                waktu_kejadian: "",
                lokasi: "",
                bukti_file: null,
            });

            setTimeout(() => {
                if (onSuccess) {
                    onSuccess();
                } else {
                    window.location.href = "/mahasiswa/status-laporan";
                }
            }, 2000);
        } catch (error) {
            console.log(error.response?.data);

            if (error.response?.status === 422) {
                const errors = error.response.data.errors;
                const firstError = Object.values(errors)[0][0];
                setMessage(firstError);
            } else {
                setMessage(
                    error.response?.data?.message || "Terjadi kesalahan saat membuat laporan"
                );
            }

            setMessageType("error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <div className="mahasiswa-header">
                <h1>Buat Laporan Kasus</h1>
                <p>Laporkan kasus yang Anda alami dengan detail yang jelas</p>
            </div>

            {message && (
                <div className={`alert alert-${messageType}`} role="alert">
                    {message}
                </div>
            )}

            <form onSubmit={handleSubmit} className="form-laporan">
                <div className="form-group">
                    <label htmlFor="kategori_kasus">
                        Kategori Kasus <span className="required">*</span>
                    </label>
                    <select
                        id="kategori_kasus"
                        name="kategori_kasus"
                        value={formData.kategori_kasus}
                        onChange={handleChange}
                        required
                        className="form-control"
                    >
                        <option value="">-- Pilih Kategori --</option>
                        {kategoriList.length > 0
                            ? kategoriList.map((kategori) => (
                                  <option key={kategori.id} value={kategori.id}>
                                      {kategori.nama_kategori}
                                  </option>
                              ))
                            : <option value="">-- Tidak ada kategori --</option>
                        }
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="deskripsi">
                        Deskripsi Kasus <span className="required">*</span>
                    </label>
                    <textarea
                        id="deskripsi"
                        name="deskripsi"
                        value={formData.deskripsi}
                        onChange={handleChange}
                        required
                        rows="6"
                        placeholder="Jelaskan kasus yang Anda alami secara detail..."
                        className="form-control"
                    ></textarea>
                    <small className="form-text">Minimum 20 karakter</small>
                </div>

                <div className="form-row">
                    <div className="form-group">
                        <label htmlFor="waktu_kejadian">
                            Waktu Kejadian <span className="required">*</span>
                        </label>
                        <input
                            type="datetime-local"
                            id="waktu_kejadian"
                            name="waktu_kejadian"
                            value={formData.waktu_kejadian}
                            onChange={handleChange}
                            required
                            className="form-control"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="lokasi">
                            Lokasi Kejadian <span className="required">*</span>
                        </label>
                        <input
                            type="text"
                            id="lokasi"
                            name="lokasi"
                            value={formData.lokasi}
                            onChange={handleChange}
                            required
                            placeholder="Contoh: Gedung A, Ruang 301"
                            className="form-control"
                        />
                    </div>
                </div>

                <div className="form-group">
                    <label htmlFor="bukti_file">Bukti Pendukung (Opsional)</label>
                    <div className="file-upload">
                        <input
                            type="file"
                            id="bukti_file"
                            name="bukti_file"
                            onChange={handleFileChange}
                            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
                            className="form-control"
                        />
                        <small className="form-text">
                            Format: PDF, DOC, DOCX, JPG, JPEG, PNG, GIF (Max 5MB)
                        </small>
                    </div>
                    {formData.bukti_file && (
                        <div className="file-info">File: {formData.bukti_file.name}</div>
                    )}
                </div>

                <div className="form-actions">
                    <button type="submit" disabled={loading} className="btn btn-primary">
                        {loading ? "Mengirim..." : "Kirim Laporan"}
                    </button>
                    <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => {
                            if (onSuccess) onSuccess();
                        }}
                    >
                        Batal
                    </button>
                </div>
            </form>
        </>
    );
}
