import { useEffect, useState } from "react";
import api from "../../api/axios";

export default function RiwayatLaporan() {
    const [laporan, setLaporan] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getData();
    }, []);

    const getData = async () => {
        try {
            const res = await api.get("/mahasiswa/riwayat-laporan");
            setLaporan(res.data.data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <p style={{ textAlign: "center" }}>Loading...</p>;

    return (
        <>
            {/* ================= CSS INTERNAL ================= */}
            <style>{`
                .riwayat-container {
                    max-width: 900px;
                    margin: 40px auto;
                    padding: 20px;
                    font-family: Arial, sans-serif;
                }

                .riwayat-container h2 {
                    text-align: center;
                    margin-bottom: 30px;
                }

                .laporan-card {
                    background: #fff;
                    border-radius: 10px;
                    padding: 20px;
                    margin-bottom: 20px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                }

                .laporan-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 15px;
                }

                .status {
                    padding: 6px 12px;
                    border-radius: 20px;
                    font-size: 12px;
                    font-weight: bold;
                    text-transform: uppercase;
                    color: white;
                }

                .status.pending {
                    background: #f0ad4e;
                }

                .status.under_review {
                    background: #0dcaf0;
                }

                .status.resolved {
                    background: #198754;
                }

                .status.rejected {
                    background: #dc3545;
                }

                .tanggal {
                    font-size: 12px;
                    color: #666;
                }

                .deskripsi {
                    background: #f8f9fa;
                    padding: 15px;
                    border-radius: 8px;
                    margin-top: 10px;
                }

                .tanggapan {
                    background: #e7f3ff;
                    padding: 15px;
                    border-radius: 8px;
                    margin-top: 15px;
                    border-left: 4px solid #0d6efd;
                }

                a {
                    color: #0d6efd;
                    text-decoration: none;
                }

                a:hover {
                    text-decoration: underline;
                }
            `}</style>

            {/* ================= HTML ================= */}
            <div className="riwayat-container">
                <h2>📄 Riwayat Laporan Saya</h2>

                {laporan.length === 0 && <p>Belum ada laporan.</p>}

                {laporan.map((item) => (
                    <div key={item.id} className="laporan-card">
                        <div className="laporan-header">
                            <span className={`status ${item.status}`}>
                                {item.status}
                            </span>
                            <span className="tanggal">
                                {item.dibuat_pada}
                            </span>
                        </div>

                        <p><b>Kategori:</b> {item.kategori_kasus}</p>
                        <p><b>Waktu Kejadian:</b> {item.waktu_kejadian}</p>
                        <p><b>Lokasi:</b> {item.lokasi}</p>

                        <div className="deskripsi">
                            <b>Deskripsi:</b>
                            <p>{item.deskripsi}</p>
                        </div>

                        {item.bukti_file && (
                            <p>
                                <b>Bukti:</b>{" "}
                                <a
                                    href={item.bukti_file}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Lihat File
                                </a>
                            </p>
                        )}

                        {item.tanggapan && (
                            <div className="tanggapan">
                                <b>Tanggapan Petugas:</b>
                                <p>{item.tanggapan}</p>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </>
    );
}
