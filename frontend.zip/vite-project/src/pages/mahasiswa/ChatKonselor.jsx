import { useState, useEffect, useRef } from "react";
import axios from "axios";
import "../../styles/mahasiswa.css";

export default function ChatKonselor({ konsultasiId, onBack }) {
    const [messages, setMessages] = useState([]);
    const [inputMessage, setInputMessage] = useState("");
    const [konsultasi, setKonsultasi] = useState(null);
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        fetchKonsultasi();
        fetchMessages();

        // Poll for new messages every 2 seconds
        const interval = setInterval(fetchMessages, 2000);
        return () => clearInterval(interval);
    }, [konsultasiId]);

    useEffect(() => {
        // Auto scroll to bottom
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const fetchKonsultasi = async () => {
        try {
            const response = await axios.get(
                `http://localhost:8000/api/mahasiswa/konsultasi/${konsultasiId}`,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );
            setKonsultasi(response.data.data || response.data);
        } catch (error) {
            console.error("Error fetching konsultasi:", error);
        }
    };

    const fetchMessages = async () => {
        try {
            const response = await axios.get(
                `http://localhost:8000/api/mahasiswa/chat/${konsultasiId}`,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );
            setMessages(response.data.data || response.data);
            setLoading(false);
        } catch (error) {
            console.error("Error fetching messages:", error);
            setLoading(false);
        }
    };

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if (!inputMessage.trim()) return;

        setSending(true);
        try {
            const response = await axios.post(
                `http://localhost:8000/api/mahasiswa/chat/${konsultasiId}`,
                {
                    pesan: inputMessage,
                    tipe: "mahasiswa",
                },
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                }
            );

            setMessages([...messages, response.data.data || response.data]);
            setInputMessage("");
        } catch (error) {
            alert("Gagal mengirim pesan. Silakan coba lagi.");
        } finally {
            setSending(false);
        }
    };

    const handleEndConsultation = async () => {
        if (
            window.confirm(
                "Apakah Anda yakin ingin mengakhiri konsultasi ini?"
            )
        ) {
            try {
                await axios.put(
                    `http://localhost:8000/api/mahasiswa/konsultasi/${konsultasiId}/end`,
                    {},
                    {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    }
                );
                if (onBack) {
                    onBack();
                } else {
                    navigate("/mahasiswa/konsultasi");
                }
            } catch (error) {
                alert("Gagal mengakhiri konsultasi. Silakan coba lagi.");
            }
        }
    };

    if (loading) {
        return (
            <>
                <p className="loading">Memuat chat...</p>
            </>
        );
    }

    if (!konsultasi) {
        return (
            <>
                <p className="error">Konsultasi tidak ditemukan</p>
                <button
                    className="btn btn-primary"
                    onClick={() => {
                        if (onBack) onBack();
                    }}
                >
                    Kembali
                </button>
            </>
        );
    }

    return (
        <>
            <div className="chat-container">
                    <div className="chat-header">
                        <div className="chat-info">
                            <h2>{konsultasi.topik}</h2>
                            <p>
                                Konselor:{" "}
                                {konsultasi.konselor_nama || "Menunggu penugasan"}
                            </p>
                        </div>
                        <div className="chat-actions">
                            <button
                                className="btn btn-secondary"
                                onClick={() => {
                                    if (onBack) onBack();
                                }}
                            >
                                Kembali
                            </button>
                            {konsultasi.status === "ongoing" && (
                                <button
                                    className="btn btn-danger"
                                    onClick={handleEndConsultation}
                                >
                                    Akhiri Konsultasi
                                </button>
                            )}
                        </div>
                    </div>

                    <div className="messages-container">
                        {messages.length === 0 ? (
                            <div className="empty-chat">
                                <p>Belum ada pesan</p>
                            </div>
                        ) : (
                            messages.map((msg, index) => (
                                <div
                                    key={index}
                                    className={`message ${
                                        msg.tipe === "mahasiswa"
                                            ? "message-sent"
                                            : "message-received"
                                    }`}
                                >
                                    <div className="message-content">
                                        <p className="message-text">
                                            {msg.pesan}
                                        </p>
                                        <span className="message-time">
                                            {new Date(
                                                msg.created_at
                                            ).toLocaleTimeString("id-ID", {
                                                hour: "2-digit",
                                                minute: "2-digit",
                                            })}
                                        </span>
                                    </div>
                                </div>
                            ))
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {konsultasi.status === "ongoing" ? (
                        <form onSubmit={handleSendMessage} className="message-input-form">
                            <div className="input-wrapper">
                                <input
                                    type="text"
                                    value={inputMessage}
                                    onChange={(e) =>
                                        setInputMessage(e.target.value)
                                    }
                                    placeholder="Ketik pesan Anda..."
                                    className="message-input"
                                    disabled={sending}
                                />
                                <button
                                    type="submit"
                                    disabled={sending || !inputMessage.trim()}
                                    className="btn btn-send"
                                >
                                    {sending ? "Mengirim..." : "Kirim"}
                                </button>
                            </div>
                        </form>
                    ) : (
                        <div className="chat-closed">
                            <p>Konsultasi telah ditutup</p>
                        </div>
                    )}
            </div>
        </>
    );
}
