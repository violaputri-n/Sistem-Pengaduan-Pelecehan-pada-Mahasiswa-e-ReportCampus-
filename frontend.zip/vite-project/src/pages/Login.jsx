import { useState } from "react";
import api from "../api/axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    async function handleLogin(e) {
        e.preventDefault();
        setError("");

        try {
            const response = await api.post("/login", { email, password });
            const data = response.data;

            localStorage.setItem("token", data.token);
            localStorage.setItem("role", data.role);

            switch (data.role) {
                case "admin":
                    navigate("/admin/dashboard");
                    break;
                case "petugas":
                    navigate("/petugas/dashboard");
                    break;
                case "konselor":
                    navigate("/konselor/dashboard");
                    break;
                case "mahasiswa":
                    navigate("/mahasiswa/dashboard");
                    break;
                default:
                    navigate("/login");
            }
        } catch {
            setError("Email atau password salah!");
        }
    }

    return (
        <div style={loginWrapper}>
            <form onSubmit={handleLogin} style={loginForm}>
                <h2>Login Sistem</h2>

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />

                {error && <p style={{ color: "red" }}>{error}</p>}

                <button type="submit">Login</button>

                <button
                    type="button"
                    onClick={() => navigate("/register-mahasiswa")}
                    style={{
                        background: "#6f42c1",
                        color: "white",
                        border: "none",
                        padding: "10px",
                        borderRadius: "5px"
                    }}
                >
                    Register Mahasiswa
                </button>
            </form>
        </div>
    );
}

const loginWrapper = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "#f0f2f5",
};

const loginForm = {
    display: "flex",
    flexDirection: "column",
    padding: "40px",
    borderRadius: "10px",
    background: "#fff",
    width: "300px",
    gap: "15px",
};
