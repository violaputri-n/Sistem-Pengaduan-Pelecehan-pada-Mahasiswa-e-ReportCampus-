import { Link } from "react-router-dom";
import DashboardLayout from "../../components/DashboardLayout";

export default function DashboardKonselor() {
  return (
    <DashboardLayout role="konselor">
      <h1>Selamat Datang, Konselor!</h1>
      <p>Pilih menu di sidebar untuk mengakses halaman.</p>

      <div style={{ display: "flex", gap: "20px", marginTop: "30px", flexWrap: "wrap" }}>
        <Link to="/konselor/permintaan" style={cardStyle}>
          <h3>Daftar Permintaan Konseling</h3>
          <p>Lihat semua permintaan konseling dari mahasiswa.</p>
        </Link>

        {/* Card Baru untuk Catatan Hasil Konseling */}
<Link to="/konselor/catatan" style={cardStyle}>
  <h3>Catatan Hasil Konseling</h3>
  <p>Tambah dan lihat catatan hasil konseling.</p>
</Link>


      </div>
    </DashboardLayout>
  );
}

const cardStyle = {
  display: "block",
  flex: "1 1 250px",
  padding: "20px",
  background: "#f8f9fa",
  borderRadius: "10px",
  textDecoration: "none",
  color: "#000",
  boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
  transition: "transform 0.2s, box-shadow 0.2s",
  minWidth: "250px"
};
