import { useState, useEffect } from "react";
import axios from "axios";
import DashboardLayout from "../../components/DashboardLayout";

// Supaya Laravel Sanctum bisa membaca cookie (login)
axios.defaults.withCredentials = true;

export default function CatatanHasilKonseling() {
  const [catatan, setCatatan] = useState([]);
  const [form, setForm] = useState({
    nama_mahasiswa: "",
    catatan: "",
    konselor: "",
    tanggal: ""
  });
  const [loading, setLoading] = useState(true);

  // Ubah URL ke route konselor
  const API_URL = "http://localhost:8000/api/konselor/catatan";

  // Ambil data dari backend
  const fetchCatatan = async () => {
    try {
      const res = await axios.get(API_URL);
      setCatatan(res.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCatatan();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(API_URL, form);
      // Tambahkan catatan baru ke state
      setCatatan([res.data, ...catatan]);
      // Reset form
      setForm({ nama_mahasiswa: "", catatan: "", konselor: "", tanggal: "" });
      alert("Catatan berhasil disimpan!");
    } catch (err) {
      console.error(err);
      if (err.response && err.response.status === 422) {
        // Tampilkan validasi error Laravel
        alert("Validasi gagal: " + JSON.stringify(err.response.data));
      } else {
        alert("Terjadi kesalahan saat menyimpan catatan");
      }
    }
  };

  return (
    <DashboardLayout role="konselor">
      <h1>Catatan Hasil Konseling</h1>

      {/* Form Input Catatan */}
      <form onSubmit={handleSubmit} style={{ marginTop: "20px", marginBottom: "30px" }}>
        <div style={{ marginBottom: "10px" }}>
          <label>Nama Mahasiswa:</label><br />
          <input type="text" name="nama_mahasiswa" value={form.nama_mahasiswa} onChange={handleChange} required style={inputStyle} />
        </div>

        <div style={{ marginBottom: "10px" }}>
          <label>Catatan:</label><br />
          <textarea name="catatan" value={form.catatan} onChange={handleChange} required style={inputStyle}></textarea>
        </div>

        <div style={{ marginBottom: "10px" }}>
          <label>Konselor:</label><br />
          <input type="text" name="konselor" value={form.konselor} onChange={handleChange} required style={inputStyle} />
        </div>

        <div style={{ marginBottom: "10px" }}>
          <label>Tanggal:</label><br />
          <input type="date" name="tanggal" value={form.tanggal} onChange={handleChange} required style={inputStyle} />
        </div>

        <button type="submit" style={buttonStyle}>Simpan Catatan</button>
      </form>

      {/* Tabel Catatan */}
      <h2>Daftar Catatan</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={thStyle}>#</th>
              <th style={thStyle}>Nama Mahasiswa</th>
              <th style={thStyle}>Catatan</th>
              <th style={thStyle}>Konselor</th>
              <th style={thStyle}>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            {catatan.length === 0 ? (
              <tr>
                <td colSpan="5" style={{ textAlign: "center", padding: "10px" }}>Belum ada catatan</td>
              </tr>
            ) : (
              catatan.map((c, index) => (
                <tr key={c.id || index}>
                  <td style={tdStyle}>{index + 1}</td>
                  <td style={tdStyle}>{c.nama_mahasiswa}</td>
                  <td style={tdStyle}>{c.catatan}</td>
                  <td style={tdStyle}>{c.konselor}</td>
                  <td style={tdStyle}>{c.tanggal}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </DashboardLayout>
  );
}

const inputStyle = { width: "100%", padding: "8px", borderRadius: "5px", border: "1px solid #ccc" };
const buttonStyle = { padding: "10px 20px", background: "#007bff", color: "#fff", border: "none", borderRadius: "5px", cursor: "pointer" };
const thStyle = { border: "1px solid #ddd", padding: "8px", background: "#f2f2f2" };
const tdStyle = { border: "1px solid #ddd", padding: "8px" };
