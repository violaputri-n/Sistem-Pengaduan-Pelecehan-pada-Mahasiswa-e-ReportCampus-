import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import api from "../../api/axios";
import DashboardLayout from "../../components/DashboardLayout";
import "../../styles/petugas.css";

export default function KonselorChat() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [mahasiswaName, setMahasiswaName] = useState("");
    const [message, setMessage] = useState("");
    const [date, setDate] = useState("");
    const [time, setTime] = useState("");
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState("");
    const [error, setError] = useState("");

    useEffect(() => {
        // Try to fetch permintaan to get mahasiswa name
        const fetchPermintaan = async () => {
            try {
                const res = await api.get("/konselor/permintaan", {
                    headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
                });
                const found = res.data.find((p) => String(p.id) === String(id));
                if (found) setMahasiswaName(found.mahasiswa?.name || "Mahasiswa");
            } catch (err) {
                console.error("Error fetching permintaan:", err);
            }
        };

        if (id) fetchPermintaan();
    }, [id]);

    const handleSubmit = async () => {
        setError("");
        setSuccess("");

        if (!message || !date || !time) {
            setError("Harap isi pesan, tanggal, dan waktu.");
            return;
        }

        setLoading(true);
        try {
            const tanggal = new Date(`${date}T${time}`);
            const isoTanggal = tanggal.toISOString();

            // Send to server in one request (will create catatan, update permintaan, and create notification)
            await api.post(
                `/konselor/permintaan/${id}/tanggapan-schedule`,
                {
                    message,
                    tanggal: isoTanggal,
                },
                { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
            );

            setSuccess("Tanggapan dan jadwal berhasil dikirim dan notifikasi dikirim ke mahasiswa.");
            setMessage("");
            setDate("");
            setTime("");
        } catch (err) {
            console.error(err);
            setError("Gagal mengirim. Coba lagi.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <DashboardLayout role="Konselor">
            <div className="petugas-container">
                <div className="petugas-header">
                    <h1>Konsultasi #{id}</h1>
                    <p>Ruang konsultasi untuk permintaan ID {id}.</p>
                </div>

                <div style={{ background: "#fff", padding: 20, borderRadius: 8 }}>
                    <p>
                        <strong>Mahasiswa:</strong> {mahasiswaName || "-"}
                    </p>

                    <label style={{ display: "block", marginTop: 10 }}>Pesan / Tanggapan</label>
                    <textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Tulis tanggapan untuk mahasiswa..."
                        style={{ width: "100%", height: 120, padding: 8 }}
                    />

                    <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
                        <div style={{ flex: 1 }}>
                            <label>Tanggal Konsultasi</label>
                            <input
                                type="date"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                                style={{ width: "100%", padding: 8 }}
                            />
                        </div>
                        <div style={{ width: 160 }}>
                            <label>Waktu</label>
                            <input
                                type="time"
                                value={time}
                                onChange={(e) => setTime(e.target.value)}
                                style={{ width: "100%", padding: 8 }}
                            />
                        </div>
                    </div>

                    {error && <p style={{ color: "red" }}>{error}</p>}
                    {success && <p style={{ color: "green" }}>{success}</p>}

                    <div style={{ marginTop: 20 }}>
                        <button
                            onClick={handleSubmit}
                            disabled={loading}
                            style={{ padding: "10px 16px", background: "#4b49ac", color: "white", border: "none", borderRadius: 6, marginRight: 8 }}
                        >
                            {loading ? "Mengirim..." : "Kirim Tanggapan & Jadwalkan"}
                        </button>

                        <button
                            onClick={() => navigate(-1)}
                            style={{ padding: "8px 16px", borderRadius: 6, background: "#6c757d", color: "white", border: "none" }}
                        >
                            Kembali
                        </button>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}