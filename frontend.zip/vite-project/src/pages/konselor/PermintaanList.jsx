import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../../api/axios";
import DashboardLayout from "../../components/DashboardLayout";

export default function PermintaanList() {
    const [data, setData] = useState([]);
    const navigate = useNavigate();

    const load = async () => {
        try {
            const res = await api.get("/konselor/permintaan");
            setData(res.data);
        } catch (err) {
            console.error("Gagal load data:", err);
        }
    };

    useEffect(() => {
        load();
    }, []);

    // ✅ TERIMA → approved
    const terima = async (id) => {
        try {
            await api.put(`/konselor/permintaan/${id}`, {
                status: "approved",
            });
            load();
        } catch (err) {
            console.error("Gagal menerima:", err);
        }
    };

    // ✅ TOLAK → rejected
    const tolak = async (id) => {
        try {
            await api.put(`/konselor/permintaan/${id}`, {
                status: "rejected",
            });
            load();
        } catch (err) {
            console.error("Gagal menolak:", err);
        }
    };

    // ✅ Mulai konsultasi
    const mulaiKonsul = (id) => {
        navigate(`/konselor/chat/${id}`);
    };

    return (
        <DashboardLayout role="Konselor">
            <h1 style={{ marginBottom: 10 }}>Permintaan Konseling</h1>

            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                    <tr>
                        <th style={thStyle}>Mahasiswa</th>
                        <th style={thStyle}>Topik</th>
                        <th style={thStyle}>Status</th>
                        <th style={thStyle}>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    {data.length === 0 && (
                        <tr>
                            <td colSpan={4} style={{ textAlign: "center", padding: 20 }}>
                                Tidak ada permintaan konseling
                            </td>
                        </tr>
                    )}

                    {data.map((row) => (
                        <tr key={row.id}>
                            <td style={tdStyle}>
                                {row.mahasiswa?.name || "-"}
                            </td>

                            <td style={tdStyle}>{row.topik}</td>
                            <td style={tdStyle}>{row.status}</td>

                            <td style={tdStyle}>
                                {row.status === "pending" && (
                                    <>
                                        <button
                                            onClick={() => terima(row.id)}
                                            style={btnPrimary}
                                        >
                                            Terima
                                        </button>
                                        <button
                                            onClick={() => tolak(row.id)}
                                            style={btnDanger}
                                        >
                                            Tolak
                                        </button>
                                    </>
                                )}

                                {row.status === "approved" && (
                                    <>
                                        <button
                                            onClick={() => mulaiKonsul(row.id)}
                                            style={btnPrimary}
                                        >
                                            Mulai Konsultasi
                                        </button>

                                        <Link
                                            to={`/konselor/catatan/${row.id}`}
                                            style={{ marginLeft: 8 }}
                                        >
                                            Catatan
                                        </Link>
                                    </>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </DashboardLayout>
    );
}

/* ================= STYLING ================= */

const thStyle = {
    padding: "10px",
    background: "#f0f0f0",
    borderBottom: "1px solid #ccc",
    textAlign: "left",
};

const tdStyle = {
    padding: "10px",
    borderBottom: "1px solid #ddd",
};

const btnPrimary = {
    background: "#4b49ac",
    color: "white",
    border: "none",
    padding: "6px 10px",
    marginRight: 8,
    borderRadius: 6,
    cursor: "pointer",
};

const btnDanger = {
    background: "#e63946",
    color: "white",
    border: "none",
    padding: "6px 10px",
    borderRadius: 6,
    cursor: "pointer",
};
