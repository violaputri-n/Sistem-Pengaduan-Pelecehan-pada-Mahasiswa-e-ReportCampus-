import { Link } from "react-router-dom";
import LogoutButton from "./LogoutButton";

export default function DashboardLayout({ role, children }) {
  const roleLower = role.toLowerCase();

  return (
    <div style={{ display: "flex" }}>
      <aside style={sidebarStyle}>
        <h2 style={{ marginBottom: "20px" }}>{role} Panel</h2>

        <ul style={menuList}>
          {/* ADMIN */}
          {roleLower === "admin" && (
            <>
              <li><Link to="/admin/dashboard" style={menuItem}>Dashboard</Link></li>
              <li><Link to="/admin/users" style={menuItem}>Manajemen User</Link></li>
              <li><Link to="/admin/kategori" style={menuItem}>Manajemen Kategori Kasus</Link></li>
            </>
          )}

          {/* KONSELOR */}
          {roleLower === "konselor" && (
            <>
              <li><Link to="/konselor/dashboard" style={menuItem}>Dashboard</Link></li>
              <li><Link to="/konselor/permintaan" style={menuItem}>Daftar Permintaan</Link></li>
              <li><Link to="/konselor/catatan" style={menuItem}>Catatan Konseling</Link></li>
            </>
          )}

          {/* PETUGAS */}
          {roleLower === "petugas" && (
            <>
              <li><Link to="/petugas/dashboard" style={menuItem}>Dashboard</Link></li>
              <li><Link to="/petugas/daftar-laporan" style={menuItem}>Daftar Laporan</Link></li>
            </>
          )}

          {/* MAHASISWA */}
          {roleLower === "mahasiswa" && (
            <>
              <li><Link to="/mahasiswa/dashboard" style={menuItem}>Dashboard</Link></li>
              <li><Link to="/mahasiswa/laporan" style={menuItem}>📝 Buat Laporan</Link></li>
              <li><Link to="/mahasiswa/riwayat" style={menuItem}>📄 Riwayat Laporan</Link></li>
              <li><Link to="/mahasiswa/konsultasi" style={menuItem}>💬 Konsultasi</Link></li>
              <li><Link to="/mahasiswa/notifikasi" style={menuItem}>🔔 Notifikasi</Link></li>
            </>
          )}
        </ul>

        <div style={{ marginTop: "30px" }}>
          <LogoutButton />
        </div>
      </aside>

      <main style={contentStyle}>
        <div style={header}>
          <h2 style={{ margin: 0 }}>Dashboard {role}</h2>
          <LogoutButton />
        </div>
        {children}
      </main>
    </div>
  );
}

const sidebarStyle = {
  width: "250px",
  padding: "20px",
  background: "#4b49ac",
  minHeight: "100vh",
  color: "white",
};

const menuList = {
  listStyle: "none",
  padding: 0,
};

const menuItem = {
  color: "white",
  textDecoration: "none",
  display: "block",
  padding: "10px 0",
};

const contentStyle = {
  flex: 1,
  padding: "30px",
  background: "#f8f9fa",
};

const header = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: "25px",
};
