<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\KategoriKasusController;
use App\Http\Controllers\CatatanApiController;
use App\Http\Controllers\LaporanKasusController;
use App\Http\Controllers\StatistikLaporanController;
use App\Http\Controllers\StatistikLaporanMahasiswaController;
use App\Http\Controllers\KonsultasiMahasiswaController;
use App\Http\Controllers\KonsultasiController;
use App\Http\Controllers\NotificationController;

Route::middleware('auth:sanctum')->prefix('mahasiswa')->group(function () {
    Route::get('/notifikasi', [NotificationController::class, 'index']);
    Route::put('/notifikasi/{id}', [NotificationController::class, 'read']);
});

Route::middleware('auth:sanctum')->prefix('mahasiswa')->group(function () {

    Route::post('/laporan-kasus', [LaporanKasusController::class, 'store']);

    Route::get('/laporan-kasus', [LaporanKasusController::class, 'riwayatMahasiswa']);

    Route::get('/laporan-terbaru', [LaporanKasusController::class, 'laporanTerbaru']);

    Route::get('/kategori-kasus', [LaporanKasusController::class, 'getKategoriKasus']);

    Route::get('/konsultasi', [KonsultasiMahasiswaController::class, 'index']);
    Route::post('/konsultasi', [KonsultasiMahasiswaController::class, 'store']);

    Route::get('/dashboard/stats', [StatistikLaporanMahasiswaController::class, 'index']);
});

Route::middleware('auth:sanctum')->prefix('konselor')->group(function () {
    Route::get('/permintaan', [KonsultasiController::class, 'index']);
    Route::put('/permintaan/{id}', [KonsultasiController::class, 'update']);
    Route::post('/permintaan/{id}/tanggapan-schedule', [KonsultasiController::class, 'tanggapanSchedule']);
    Route::get('/dashboard', fn () => response()->json(['message' => 'Dashboard Konselor']));
});

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/petugas/laporan-masuk', [LaporanKasusController::class, 'index']);
    Route::post('/petugas/laporan/{id}/tindaklanjut', [LaporanKasusController::class, 'tindaklanjut']);
    Route::post('/petugas/laporan/{id}/tanggapan', [LaporanKasusController::class, 'tanggapan']);
    Route::get('/petugas/statistik-laporan', [StatistikLaporanController::class, 'index']);
    Route::get('/petugas/dashboard', fn () => response()->json(['message' => 'Dashboard Petugas']));
});

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/admin/dashboard', fn () => response()->json(['message' => 'Dashboard Admin']));
});

Route::post('/login', [AuthController::class, 'login']);
Route::post('/register/mahasiswa', [AuthController::class, 'registerMahasiswa']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

Route::get('/users', [UserController::class, 'index']);
Route::post('/users', [UserController::class, 'store']);
Route::put('/users/{user}', [UserController::class, 'update']);
Route::delete('/users/{user}', [UserController::class, 'destroy']);

Route::get('/kategori', [KategoriKasusController::class, 'index']);
Route::post('/kategori', [KategoriKasusController::class, 'store']);
Route::put('/kategori/{kategoriKasus}', [KategoriKasusController::class, 'update']);
Route::delete('/kategori/{kategoriKasus}', [KategoriKasusController::class, 'destroy']);

Route::get('/catatan', [CatatanApiController::class, 'index']);
Route::post('/catatan', [CatatanApiController::class, 'store']);
